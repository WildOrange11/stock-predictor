
import os, re, time, json
import pandas as pd
from openai import OpenAI, RateLimitError, APIError

MODEL        = 'gpt-5.4-mini'
RETRY_LIMIT  = 3
RETRY_DELAY  = 5
LABELS       = ("Positive", "Negative", "Neutral")

FLAIR_LABEL_MAP = {
    "Gain": "Positive",
    "Loss": "Negative"
}

WSB_FEW_SHOT_EXAMPLES = [
    {
        "text": "Officially hit 7 figures",
        "label": "Positive"
    },
    {
        "text": "$20k to $100k because of the SpaceX IPO, hop in, boys",
        "label": "Positive"
    },
    {
        "text": "I listened to that SpaceX IPO DD guy and it paid off",
        "label": "Positive"
    },
    {
        "text": "Blew up my account after joining Wealth simple",
        "label": "Negative"
    },
    {
        "text": "Revenge trade burned",
        "label": "Negative"
    },
    {
        "text": "Down so bad",
        "label": "Negative"
    },
    {
        "text": "SpaceX awarded $6.45B in Space Force contracts ahead of IPO",
        "label": "Neutral"
    },
    {
        "text": "Anthropic Files to Go Public, Setting Stage for Huge I.P.O.",
        "label": "Neutral"
    },
    {
        "text": "DD: HOOD Could Benefit as the $25K Pattern Day Trader Barrier Starts Falling Next Week 🚀",
        "label": "Neutral"
    }
]

WSB_SYSTEM_PROMPT = """{prompt}""".format(prompt='You are a **financial sentiment analyst** judging the sentiment of a single stock-market tweet. Determine whether the tweet is **Positive**, **Neutral**, or **Negative** toward the market/asset(s) it mentions.\n\n**Definitions (use these rules):**\n- **Positive**: Expresses optimism or favorable expectations about a company/stock/sector/market.\n  *Examples:* “$AAPL will beat earnings,” “strong guidance,” “bullish,” “priced in a breakout,” “analyst upgrade to Buy,” “fundamentals look great.”\n- **Neutral**: Mostly factual, informational, or uncertain without clear positive/negative direction.\n  *Examples:* “$TSLA reports earnings on Tuesday,” “shares trade flat,” “watching next quarter,” “no change in rating,” “volatile but unclear,” “company announced results.”\n- **Negative**: Expresses pessimism, risk, or unfavorable expectations.\n  *Examples:* “$MSFT missed earnings,” “cutting guidance,” “bearish,” “analyst downgrade to Sell,” “bankruptcy concerns,” “lawsuit/SEC investigation,” “looks like a breakdown.”\n\nAnswer with only "positive", "negative", or "neutral"')


def _build_prompt(target):
    parts = [WSB_SYSTEM_PROMPT, ""]
    for ex in WSB_FEW_SHOT_EXAMPLES:
        parts.append(f"Post: {ex['text']}\nSentiment: {ex['label']}")
    parts.append(f"Post: {target.strip()}\nSentiment:")
    return "\n\n".join(parts)


def _call_llm(prompt, client):
    for attempt in range(RETRY_LIMIT):
        try:
            response = client.responses.create(model=MODEL, input=prompt)
            raw = response.output_text.strip().capitalize()
            if raw in LABELS:
                return raw
            for label in LABELS:
                if label in raw:
                    return label
            return None
        except RateLimitError:
            time.sleep(RETRY_DELAY * (attempt + 1))
        except APIError as e:
            print(f"[classifier] API error: {e}")
            time.sleep(RETRY_DELAY)
    return None


def _extract_ticker(text):
    match = re.search(r'\$([A-Z]{1,5})\b', str(text))
    return match.group(1) if match else None


def _get_client(client, api_key):
    if client is not None:
        return client
    key = api_key or os.environ.get("OPENAI_API_KEY")
    if not key:
        raise ValueError(
            "No OpenAI client or API key provided. Pass client=OpenAI(api_key=...) "
            "or set the OPENAI_API_KEY environment variable in Replit Secrets."
        )
    return OpenAI(api_key=key)


def classify_post(text, flair=None, client=None, api_key=None):
    """Classify a single WSB post. Returns dict with sentiment, method, ticker, confidence."""
    ticker = _extract_ticker(text)
    if flair and flair in FLAIR_LABEL_MAP:
        return {"sentiment": FLAIR_LABEL_MAP[flair], "method": "rules_based",
                 "ticker": ticker, "confidence": "high"}
    _client = _get_client(client, api_key)
    label   = _call_llm(_build_prompt(text), _client)
    return {"sentiment": label or "Neutral", "method": "llm_judge",
             "ticker": ticker, "confidence": "model"}


def classify_dataframe(df, text_col="title", flair_col="flair", client=None, api_key=None):
    """Classify a full DataFrame. Adds sentiment, classification_method, ticker columns."""
    from tqdm.auto import tqdm
    _client = _get_client(client, api_key)
    results = []
    for _, row in tqdm(df.iterrows(), total=len(df), desc="Classifying"):
        text  = str(row.get(text_col, ""))
        flair = str(row.get(flair_col, "")) if flair_col else None
        results.append(classify_post(text, flair=flair, client=_client))
    out = df.copy()
    out["sentiment"]             = [r["sentiment"] for r in results]
    out["classification_method"] = [r["method"]    for r in results]
    out["ticker"]                = [r["ticker"]     for r in results]
    return out


def load_labeled_data(path=None):
    """Load the pre-labeled WSB dataset produced by Notebook 3."""
    if path is None:
        try:
            import model_setup
            path = model_setup.paths.get("wsb_labeled.csv")
        except ImportError:
            pass
    if path is None:
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "wsb_labeled.csv")
    if not os.path.exists(path):
        raise FileNotFoundError(f"wsb_labeled.csv not found at {path}.")
    df = pd.read_csv(path)
    if "date_utc" in df.columns:
        df["date_utc"] = pd.to_datetime(df["date_utc"], utc=True, errors="coerce")
    return df


def get_sentiment_summary(df, sentiment_col="sentiment"):
    """Return sentiment counts and percentages — useful for dashboard stat cards."""
    counts = df[sentiment_col].value_counts()
    total  = len(df)
    return {
        label: {"count": int(counts.get(label, 0)),
                "pct":   round(counts.get(label, 0) / total * 100, 1) if total else 0}
        for label in LABELS
    } | {"total": total}


def get_top_tickers(df, n=10):
    """Return top-n most-mentioned tickers with sentiment breakdown."""
    if "ticker" not in df.columns:
        df = df.copy()
        df["ticker"] = df.get("title", pd.Series(dtype=str)).apply(_extract_ticker)
    ticker_df = df.dropna(subset=["ticker"])
    if ticker_df.empty:
        return pd.DataFrame()
    rows = []
    for ticker, group in ticker_df.groupby("ticker"):
        counts = group["sentiment"].value_counts()
        total  = len(group)
        rows.append({
            "ticker"            : ticker,
            "mention_count"     : total,
            "positive_pct"      : round(counts.get("Positive", 0) / total * 100, 1),
            "negative_pct"      : round(counts.get("Negative",  0) / total * 100, 1),
            "neutral_pct"       : round(counts.get("Neutral",   0) / total * 100, 1),
            "avg_score"         : round(group["score"].mean(), 1) if "score" in group else 0,
            "dominant_sentiment": counts.idxmax() if not counts.empty else "Neutral",
        })
    return (pd.DataFrame(rows)
            .sort_values("mention_count", ascending=False)
            .head(n)
            .reset_index(drop=True))
